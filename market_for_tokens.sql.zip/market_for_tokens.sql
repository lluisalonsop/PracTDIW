-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 17-01-2022 a las 00:31:49
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `market for tokens`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `ID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`ID`, `Nombre`) VALUES
(1, 'Retro'),
(2, 'Vintage'),
(3, 'Natural'),
(4, 'Other');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `ID` int(11) NOT NULL,
  `Producto_ID` int(11) NOT NULL,
  `Pedido_ID` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Precio` float NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_header`
--

CREATE TABLE `pedido_header` (
  `ID` int(11) NOT NULL,
  `Usuaris_ID` int(11) NOT NULL,
  `Fecha` varchar(100) NOT NULL,
  `Importe_Total` float NOT NULL,
  `Total_Elementos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` text NOT NULL,
  `Foto` varchar(100) NOT NULL,
  `Precio` float NOT NULL,
  `Categoria_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID`, `Nombre`, `Descripcion`, `Foto`, `Precio`, `Categoria_ID`) VALUES
(1, 'RED', 'The first, the red, the retro.', '/public_html/recursosnew/img/RED.png', 100, 1),
(2, 'Good_ol_drinks', 'Some, clearly vintage, good ol drinks.', '/public_html/recursosnew/img/Good_ol_drinks.png', 25, 2),
(3, 'Beautiful_Mountains', 'Very natural mountains.', '/public_html/recursosnew/img/Beautiful_Mountains.png', 75, 3),
(4, 'Much Other', 'Wow, much other very other.', '/public_html/recursosnew/img/Much_other.png', 50, 4),
(6, 'BLUE', 'The perfect blue image.', '/public_html/recursosnew/img/BLUE.png', 99, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Codigo_Postal` varchar(100) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Correo_Electronico` varchar(100) NOT NULL,
  `Poblacion` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `IMG` varchar(100) NOT NULL DEFAULT '\\public_html\\recursosnew\\img\\usuari'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`ID`,`Producto_ID`,`Pedido_ID`),
  ADD KEY `Producto_ID` (`Producto_ID`),
  ADD KEY `Pedido_ID` (`Pedido_ID`);

--
-- Indices de la tabla `pedido_header`
--
ALTER TABLE `pedido_header`
  ADD PRIMARY KEY (`ID`) USING BTREE,
  ADD KEY `Usuaris_ID` (`Usuaris_ID`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Categoria_ID` (`Categoria_ID`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`Producto_ID`) REFERENCES `productos` (`ID`),
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`Pedido_ID`) REFERENCES `pedido_header` (`ID`);

--
-- Filtros para la tabla `pedido_header`
--
ALTER TABLE `pedido_header`
  ADD CONSTRAINT `pedido_header_ibfk_1` FOREIGN KEY (`Usuaris_ID`) REFERENCES `usuarios` (`ID`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`Categoria_ID`) REFERENCES `categorias` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
